class Movie {
  final String name;
  final String imagePath;
  final String videoPath;
  final String category;
  final int year;
  final Duration duration;

  const Movie({
    required this.name,
    required this.imagePath,
    required this.videoPath,
    required this.category,
    required this.duration,
    required this.year,
  });

  static const List<Movie> movies = [

    Movie(
      name: 'Hustle',
      imagePath:
        'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),
    Movie(
      name: 'Hustle',
      imagePath:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=2659&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
      videoPath: 'assets/videos/example.mov',
      category: 'Drama',
      year: 2022,
      duration: Duration(hours: 1, minutes: 58),
    ),

  ];
}